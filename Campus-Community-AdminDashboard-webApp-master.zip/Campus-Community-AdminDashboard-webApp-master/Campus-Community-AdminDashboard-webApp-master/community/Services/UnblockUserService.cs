﻿using Google.Cloud.Firestore;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Google.Cloud.Firestore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace community.Services
{
    public class UnblockUserService : BackgroundService
    {
        private readonly FirestoreDb _firestoreDb;
        private readonly ILogger<UnblockUserService> _logger;

        public UnblockUserService(FirestoreDb firestoreDb, ILogger<UnblockUserService> logger)
        {
            _firestoreDb = firestoreDb;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    _logger.LogInformation("Checking for users to unblock...");

                    // Query Firestore for users whose 'blockedUntil' is in the past
                    var usersCollection = _firestoreDb.Collection("users");
                    QuerySnapshot blockedUsersSnapshot = await usersCollection
                        .WhereLessThanOrEqualTo("blockedUntil", DateTime.UtcNow)
                        .GetSnapshotAsync();

                    foreach (var userDoc in blockedUsersSnapshot.Documents)
                    {
                        // Remove the 'blockedUntil' field to unblock the user
                        await userDoc.Reference.UpdateAsync(new Dictionary<string, object>
                    {
                        { "blockedUntil", FieldValue.Delete }
                    });

                        _logger.LogInformation($"User {userDoc.Id} has been unblocked.");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Error unblocking users: {ex.Message}");
                }

                // Wait 24 hours before running again
                await Task.Delay(TimeSpan.FromHours(24), stoppingToken);
            }
        }
    }
}
