using FirebaseAdmin;
using FirebaseAdmin.Auth;
using Google.Apis.Auth.OAuth2;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Google.Cloud.Firestore.V1;
using Google.Cloud.Firestore;
using Grpc.Auth;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using community.Services;
using Google.Api;

var builder = WebApplication.CreateBuilder(args);

// Register FirestoreDb as a singleton
builder.Services.AddSingleton(sp =>
{
    var projectId = "student-community-app";
    var credentialPath = Path.Combine(builder.Environment.ContentRootPath, "appData", "file", "student-community-app-eb5e19c4e5b9.json");
    var credential = GoogleCredential.FromFile(credentialPath);

    // Build FirestoreClient using the GoogleCredential
    var firestoreClient = new FirestoreClientBuilder
    {
        ChannelCredentials = credential.ToChannelCredentials()
    }.Build();

    return FirestoreDb.Create(projectId, firestoreClient);
});

// Configure Firebase Admin SDK and register FirebaseAuth
builder.Services.AddSingleton(sp =>
{
    var credentialPath = Path.Combine(builder.Environment.ContentRootPath, "appData", "file", "student-community-app-eb5e19c4e5b9.json");
    var credential = GoogleCredential.FromFile(credentialPath);

    var appOptions = new AppOptions
    {
        Credential = credential
    };

    var firebaseApp = FirebaseApp.Create(appOptions);

    // Register FirebaseAuth as a singleton
    return FirebaseAuth.GetAuth(firebaseApp);
});
builder.Services.AddHostedService<UnblockUserService>();

builder.Services.AddRazorPages();
builder.Services.AddHttpClient<UserService>();

// Add services to the container.
builder.Services.AddControllersWithViews();

// Configure session state
builder.Services.AddDistributedMemoryCache(); // Adds a default in-memory implementation of IDistributedCache
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Set session timeout
    options.Cookie.HttpOnly = true; // Make the session cookie HTTP-only
    options.Cookie.IsEssential = true; // Make the session cookie essential
});

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";   // Redirect to login page if not authenticated
        options.LogoutPath = "/Account/Logout";
        options.AccessDeniedPath = "/Account/AccessDenied";
    });

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Enable session middleware
app.UseSession();

// Enable authentication and authorization
app.UseAuthentication();
app.UseAuthorization();

// Update the default route to point to the login page
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}"); // Redirect to Account/Login

// Add an endpoint to trigger Firestore email creation
app.MapGet("/create-students", async (FirestoreDb db) =>
{
    CollectionReference studentsCollection = db.Collection("students");

    for (int i = 0; i < 100; i++)
    {
        string email = $"222062484{i:D2}@stud.cut.ac.za";

        Dictionary<string, object> studentData = new Dictionary<string, object>()
        {
            { "email", email }
        };

        DocumentReference docRef = await studentsCollection.AddAsync(studentData);
        Console.WriteLine($"Added student with ID: {docRef.Id} and Email: {email}");
    }

    return Results.Ok("100 student emails added to Firestore.");
});

app.Run();
