﻿using community.Models; 
using System.Collections.Generic;

namespace community.ViewModels
{
    public class StudyGroupDetailsViewModel
    {
        public StudyGroups StudyGroup { get; set; }
        public List<Message> Messages { get; set; } 
    }
}
