﻿using FirebaseAdmin.Auth;
using System.Threading.Tasks;

public class FirebaseAuthService
{
    private readonly FirebaseAuth _auth;

    public FirebaseAuthService(FirebaseAuth auth)
    {
        _auth = auth;
    }

    public async Task<UserRecord> CreateUserAsync(string email, string password)
    {
        var userRecordArgs = new UserRecordArgs()
        {
            Email = email,
            Password = password,
            EmailVerified = false,
            Disabled = false
        };
        return await _auth.CreateUserAsync(userRecordArgs);
    }

    public async Task<UserRecord> GetUserByEmailAsync(string email)
    {
        return await _auth.GetUserByEmailAsync(email);
    }

    
}
