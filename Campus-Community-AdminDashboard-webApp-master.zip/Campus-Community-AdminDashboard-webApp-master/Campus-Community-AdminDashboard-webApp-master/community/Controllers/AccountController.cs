﻿using Microsoft.AspNetCore.Mvc;
using community.Models;
using FirebaseAdmin.Auth;
using Microsoft.AspNetCore.Authentication;
using System.ComponentModel.DataAnnotations;

namespace community.Controllers
{
    public class AccountController : Controller
    {
        // Hardcoded email and password
        private readonly string _hardcodedEmail = "admin@cut.ac.za";
        private readonly string _hardcodedPassword = "password123";

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(Login model)
        {
            bool isEmailValid = IsValidEmail(model.Email);
            bool isPasswordValid = IsValidPassword(model.Password);

            // Email format validation
            if (!isEmailValid)
            {
                ModelState.AddModelError("Email", "Please enter a valid email address.");
            }

            // Password format validation
            if (!isPasswordValid)
            {
                ModelState.AddModelError("Password", "Password must be at least 8 characters long.");
            }

            if (isEmailValid && isPasswordValid && ModelState.IsValid)
            {
                // Hardcoded login check
                if (model.Email == _hardcodedEmail)
                {
                    if (model.Password == _hardcodedPassword)
                    {
                        // Handle successful login
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        // Correct email, wrong password
                        ModelState.AddModelError("Password", "The password you entered is incorrect.");
                    }
                }
                else
                {
                    if (model.Password == _hardcodedPassword)
                    {
                        // Correct password, wrong email
                        ModelState.AddModelError("Email", "The email address you entered is incorrect.");
                    }
                    else
                    {
                        // Both email and password are wrong
                        ModelState.AddModelError("", "Invalid email or password.");
                    }
                }
            }

            return View(model);
        }

        [HttpPost]
        public IActionResult Logout()
        {
            // Logic to handle logout
            HttpContext.SignOutAsync();
            return RedirectToAction("Login", "Account");
        }

        // Helper methods for validation
        private bool IsValidEmail(string email)
        {
            return new EmailAddressAttribute().IsValid(email);
        }

        private bool IsValidPassword(string password)
        {
            return password != null && password.Length >= 8;
        }
    }
}
