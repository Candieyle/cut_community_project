﻿using community.Models;
using Google.Cloud.Firestore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace community.Controllers
{
    public class ReportController : Controller
    {

        private readonly FirestoreDb _firestoreDb;

        public ReportController(FirestoreDb firestoreDb)
        {
            _firestoreDb = firestoreDb;
        }
     
        // GET: ReportController
        public async Task<ActionResult> Index()
        {
            // Collection reference to "reportedMessages"
            CollectionReference reportsCollection = _firestoreDb.Collection("reportedMessages");

            // Get all the documents in the "reportedMessages" collection
            QuerySnapshot snapshot = await reportsCollection.GetSnapshotAsync();

            // List to store the reports
            List<Report> reportList = new List<Report>();

            // Iterate through the documents and convert them to Report objects
            foreach (DocumentSnapshot document in snapshot.Documents)
            {
                if (document.Exists)
                {
                    Report report = document.ConvertTo<Report>();
                    // Ensure the document has a reportID
                    if (string.IsNullOrEmpty(report.reportID))
                    {
                        // Log or handle missing reportID
                        continue;
                    }
                    reportList.Add(report);
                }
            }


            // Pass the list of reports to the view
            return View(reportList);
        }

        // GET: ReportController/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return BadRequest("Report ID cannot be null or empty.");
            }

            var docRef = _firestoreDb.Collection("reportedMessages").Document(id);
            var snapshot = await docRef.GetSnapshotAsync();

            if (snapshot.Exists)
            {
                var report = snapshot.ConvertTo<Report>();
                return View(report);
            }

            return NotFound();
        }

        // Block user for 2 weeks
        [HttpPost("Report/BlockUser")]
        public async Task<IActionResult> BlockUser(string email, string reportID)
        {
            if (string.IsNullOrEmpty(email))
            {
                return BadRequest("Email cannot be null or empty.");
            }

            if (string.IsNullOrEmpty(reportID))
            {
                return BadRequest("Report ID cannot be null or empty.");
            }

            try
            {
                // Get the Firestore document for the user based on email
                QuerySnapshot userSnapshot = await _firestoreDb.Collection("users")
                    .WhereEqualTo("email", email)
                    .GetSnapshotAsync();

                if (userSnapshot.Count == 0)
                {
                    return NotFound("User not found.");
                }

                DocumentSnapshot userDoc = userSnapshot.Documents.First();

                // Block user by setting a 'blockedUntil' field 
                DateTime blockedUntil = DateTime.UtcNow.AddDays(1);

                await userDoc.Reference.UpdateAsync(new Dictionary<string, object>
        {
            { "blockedUntil", blockedUntil }
        });

                // Set confirmation message
                TempData["Message"] = $"User has been blocked until {blockedUntil.ToString("MMMM dd, yyyy")}.";

                // Redirect to the report details page using the provided reportID
                return RedirectToAction("Details", new { id = reportID });
            }
            catch (Exception ex)
            {
                return BadRequest("Error blocking user: " + ex.Message);
            }
        }










        // GET: ReportController/Delete/5
        // GET: ReportController/Delete/5
        [HttpGet]
        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return BadRequest("Report ID cannot be null or empty.");
            }

            // Fetch the report to confirm deletion
            var docRef = _firestoreDb.Collection("reportedMessages").Document(id);
            var snapshot = await docRef.GetSnapshotAsync();

            if (snapshot.Exists)
            {
                var report = snapshot.ConvertTo<Report>();
                return View(report); // Return a view to confirm deletion
            }

            return NotFound("Report not found.");
        }

        // POST: ReportController/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirm(string id)
        {
            try
            {
                if (string.IsNullOrEmpty(id))
                {
                    return BadRequest("Report ID cannot be null or empty.");
                }

                // Reference to the document to be deleted
                DocumentReference docRef = _firestoreDb.Collection("reportedMessages").Document(id);
                

                // Check if the document exists before trying to delete it
                DocumentSnapshot snapshot = await docRef.GetSnapshotAsync();
                if (!snapshot.Exists)
                {
                    return NotFound("Report not found.");
                }

                // Delete the document
                
                await docRef.DeleteAsync();

                TempData["Message"] = "Report successfully deleted.";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                return BadRequest("Error deleting report: " + ex.Message);
            }
        }

    }
}
