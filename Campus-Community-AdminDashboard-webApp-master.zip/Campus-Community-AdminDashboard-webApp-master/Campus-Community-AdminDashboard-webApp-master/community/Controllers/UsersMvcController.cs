﻿using community.Models;
using Google.Cloud.Firestore;
using FirebaseAdmin.Auth;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace community.Controllers
{
    public class UsersMvcController : Controller
    {
        private readonly FirestoreDb _firestoreDb;

        public UsersMvcController(FirestoreDb firestoreDb)
        {
            _firestoreDb = firestoreDb;
        }

        // GET: Users
        // GET: Users
        public async Task<IActionResult> UserManagement(string searchQuery = null)
        {
            var usersQuery = _firestoreDb.Collection("users");
            var usersSnapshot = await usersQuery.GetSnapshotAsync();
            var users = new List<User>();

            foreach (var document in usersSnapshot.Documents)
            {
                var user = document.ConvertTo<User>();

                // If there is a search query, filter users
                if (!string.IsNullOrEmpty(searchQuery))
                {
                    if (user.name.Contains(searchQuery, System.StringComparison.OrdinalIgnoreCase) ||
                        user.surname.Contains(searchQuery, System.StringComparison.OrdinalIgnoreCase) ||
                        user.email.Contains(searchQuery, System.StringComparison.OrdinalIgnoreCase) ||
                        user.phoneNumber.Contains(searchQuery))
                    {
                        users.Add(user);
                    }
                }
                else
                {
                    // If no search query, add all users
                    users.Add(user);
                }
            }

            return View(users); // Returning the filtered list of users or all users if no search
        }

        // GET: Users/Details/{email}
        public async Task<IActionResult> Details(string email)
        {
            var docRef = _firestoreDb.Collection("users").Document(email);
            var snapshot = await docRef.GetSnapshotAsync();

            if (snapshot.Exists)
            {
                var user = snapshot.ConvertTo<User>();
                return View(user);
            }

            return NotFound();
        }

        // GET: Users/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Users/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(User user)
        {
            if (ModelState.IsValid)
            {
                var docRef = _firestoreDb.Collection("users").Document(user.email); // Use email as the document ID
                var snapshot = await docRef.GetSnapshotAsync();

                if (!snapshot.Exists) // Ensure user does not already exist
                {
                    await docRef.SetAsync(user);
                    return RedirectToAction(nameof(UserManagement));
                }

                ModelState.AddModelError("", "A user with this email already exists.");
            }

            return View(user);
        }

        // GET: Users/Edit/{email}
        public async Task<IActionResult> Edit(string email)
        {
            var docRef = _firestoreDb.Collection("users").Document(email);
            var snapshot = await docRef.GetSnapshotAsync();

            if (snapshot.Exists)
            {
                var user = snapshot.ConvertTo<User>();
                return View(user);
            }

            return NotFound();
        }

        // POST: Users/Edit/{email}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string email, User user)
        {
            if (email != user.email)
            {
                return BadRequest("User email mismatch.");
            }

            if (ModelState.IsValid)
            {
                var docRef = _firestoreDb.Collection("users").Document(email);
                await docRef.SetAsync(user, SetOptions.Overwrite); // Overwrite the existing document with the new data

                return RedirectToAction(nameof(UserManagement)); // Redirect to UserManagement after successful edit
            }

            return View(user);
        }

        // GET: Users/Delete/{email}
        public async Task<IActionResult> Delete(string email)
        {
            var docRef = _firestoreDb.Collection("users").Document(email);
            var snapshot = await docRef.GetSnapshotAsync();

            if (snapshot.Exists)
            {
                var user = snapshot.ConvertTo<User>();
                return View(user);
            }

            return NotFound();
        }

        // POST: Users/Delete/{email}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string email)
        {
            var docRef = _firestoreDb.Collection("users").Document(email);
            await docRef.DeleteAsync();

            return RedirectToAction(nameof(UserManagement)); // Redirect to UserManagement after deletion
        }
    }
}
