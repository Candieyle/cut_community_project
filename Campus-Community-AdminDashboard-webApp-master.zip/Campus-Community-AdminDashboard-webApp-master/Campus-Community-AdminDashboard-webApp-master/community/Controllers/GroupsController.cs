﻿using community.Models;
using community.ViewModels;
using Google.Cloud.Firestore;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace community.Controllers
{
    public class GroupsController : Controller
    {
        private readonly FirestoreDb _firestoreDb;

        public GroupsController(FirestoreDb firestoreDb)
        {
            _firestoreDb = firestoreDb;
        }

        // GET: Groups
        public async Task<IActionResult> Index(string searchQuery)
        {
            var groupsQuery = _firestoreDb.Collection("studyGroups");
            var groupsSnapshot = await groupsQuery.GetSnapshotAsync();
            var studyGroups = new List<StudyGroups>(); // Assuming a StudyGroup model

            foreach (var document in groupsSnapshot.Documents)
            {
                var studyGroup = document.ConvertTo<StudyGroups>();
                studyGroups.Add(studyGroup);
                Console.WriteLine($"Study Group added: {studyGroup.groupName}");
            }

            // If a search query is provided, filter the study groups
            if (!string.IsNullOrEmpty(searchQuery))
            {
                studyGroups = studyGroups
                    .Where(g => g.groupName.Contains(searchQuery, StringComparison.OrdinalIgnoreCase)) // Search by group name
                    .ToList();
            }

            return View(studyGroups); // Return the list of study groups
        }



        public async Task<IActionResult> Details(string id)
        {
            var docRef = _firestoreDb.Collection("studyGroups").Document(id);
            var snapshot = await docRef.GetSnapshotAsync();

            if (snapshot.Exists)
            {
                var studyGroup = snapshot.ConvertTo<StudyGroups>();

                // Fetch messages related to the study group
                var messagesQuery = _firestoreDb.Collection("messages").WhereEqualTo("groupId", studyGroup.id);
                var messagesSnapshot = await messagesQuery.GetSnapshotAsync();
                var messages = new List<Message>();

                foreach (var doc in messagesSnapshot.Documents)
                {
                    var message = doc.ConvertTo<Message>();
                    // Check if attachments field exists and is a list of strings
                    if (doc.TryGetValue("attachments", out List<string> attachmentsField))
                    {
                        message.attachments = attachmentsField; // Directly assign the list
                    }
                    messages.Add(message);
                }

                var viewModel = new StudyGroupDetailsViewModel
                {
                    StudyGroup = studyGroup,
                    Messages = messages
                };

                return View(viewModel);
            }

            return NotFound();
        }




        public async Task<IActionResult> Delete(string id)
        {
            var docRef = _firestoreDb.Collection("studyGroups").Document(id);
            var snapshot = await docRef.GetSnapshotAsync();

            if (snapshot.Exists)
            {
                var studyGroup = snapshot.ConvertTo<StudyGroups>();
                return View(studyGroup);  
            }

            return NotFound(); 
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var docRef = _firestoreDb.Collection("studyGroups").Document(id);
            var snapshot = await docRef.GetSnapshotAsync();

            if (snapshot.Exists)
            {
               
                var studyGroup = snapshot.ConvertTo<StudyGroups>();

               
                if (studyGroup.messages != null && studyGroup.messages.Count > 0)
                {
                    var messagesCollection = _firestoreDb.Collection("messages"); 
                    var messagesToDelete = studyGroup.messages;

                    foreach (var messageId in messagesToDelete)
                    {
                        var messageDocRef = messagesCollection.Document(messageId);
                        await messageDocRef.DeleteAsync(); 
                    }
                }

               
                await docRef.DeleteAsync(); 
            }

            return RedirectToAction(nameof(Index)); 
        }

        public IActionResult Reports()
        {
            return View();
        }
    }
}
