﻿using community.Models;
using Google.Cloud.Firestore;
using Google.Protobuf.WellKnownTypes;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace community.Controllers
{
    
    public class EventsController : Controller
    {
        private readonly FirestoreDb _firestoreDb;

        public EventsController(FirestoreDb firestoreDb)
        {
            _firestoreDb = firestoreDb;
        }



        public async Task<IActionResult> Index(string searchString)
        {
            var eventsQuery = _firestoreDb.Collection("events");

            if (!string.IsNullOrEmpty(searchString))
            {
                // Create queries for each field
                var titleQuery = eventsQuery
                    .WhereGreaterThanOrEqualTo("title", searchString)
                    .WhereLessThanOrEqualTo("title", searchString + '\uf8ff');

                var descriptionQuery = eventsQuery
                    .WhereGreaterThanOrEqualTo("description", searchString)
                    .WhereLessThanOrEqualTo("description", searchString + '\uf8ff');

                var locationQuery = eventsQuery
                    .WhereGreaterThanOrEqualTo("location", searchString)
                    .WhereLessThanOrEqualTo("location", searchString + '\uf8ff');

                // Fetch the results for each query
                var titleSnapshot = await titleQuery.GetSnapshotAsync();
                var descriptionSnapshot = await descriptionQuery.GetSnapshotAsync();
                var locationSnapshot = await locationQuery.GetSnapshotAsync();

                // Combine the results
                var events = new HashSet<ManageEvents>();

                foreach (var document in titleSnapshot.Documents)
                {
                    var eventl = document.ConvertTo<ManageEvents>();
                    events.Add(eventl);
                }

                foreach (var document in descriptionSnapshot.Documents)
                {
                    var eventl = document.ConvertTo<ManageEvents>();
                    events.Add(eventl);
                }

                foreach (var document in locationSnapshot.Documents)
                {
                    var eventl = document.ConvertTo<ManageEvents>();
                    events.Add(eventl);
                }

                // Convert HashSet to List
                var eventList = events.ToList();

                // Check if no users were found
                if (!eventList.Any())
                {
                    ViewData["Message"] = "No users found.";
                }

                return View(eventList); // Return the list of users to the view
            }
            else
            {
                // If no search string, fetch all users
                var eventsSnapshot = await eventsQuery.OrderBy("title").GetSnapshotAsync();
                var events = new List<ManageEvents>();

                foreach (var document in eventsSnapshot.Documents)
                {
                    var  eventl= document.ConvertTo<ManageEvents>();
                    events.Add(eventl);
                }

                return View(events); // Return the list of users to the view
            }
        }

        // GET: Events/Details/{id}
        public async Task<IActionResult> Details(string id)
        {
            var docRef = _firestoreDb.Collection("events").Document(id);
            var snapshot = await docRef.GetSnapshotAsync();

            if (snapshot.Exists)
            {
                var eventObj = snapshot.ConvertTo<ManageEvents>();
                return View(eventObj);
            }

            return NotFound();
        }

        // GET: Events/Create
        public IActionResult Create()
        {
            return View();
        }

        /*[HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ManageEvents eventObj)
        {
            if (ModelState.IsValid)
            {
                var docRef = _firestoreDb.Collection("events").Document();
                eventObj.eventId = docRef.Id; // Assign Firestore document ID to event
                await docRef.SetAsync(eventObj);

                return RedirectToAction(nameof(Index)); // Redirect to Index after creation
            }

            return View(eventObj); // If validation fails or an error occurs, return the view
        }*/

        // POST: EventManagement/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ManageEvents eventObj)
        {
            if (ModelState.IsValid)
            {
                // Convert date and time to UTC
                eventObj.date = eventObj.date.ToUniversalTime();
                eventObj.time = eventObj.time.ToUniversalTime();

                var docRef = _firestoreDb.Collection("events").Document();
                eventObj.eventId = docRef.Id;     // Assign Firestore document ID to event
                await docRef.SetAsync(eventObj, SetOptions.Overwrite);

                return RedirectToAction(nameof(Index));
            }

            return View(eventObj);     // If validation fails or an error occurs, return the view
        }



        // GET: Events/Edit/{id}
        public async Task<IActionResult> Edit(string id)
        {
            var docRef = _firestoreDb.Collection("events").Document(id);
            var snapshot = await docRef.GetSnapshotAsync();

            if (snapshot.Exists)
            {

                var eventObj = snapshot.ConvertTo<ManageEvents>();
                return View(eventObj);
            }

            return NotFound();
        }

        // POST: Events/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, ManageEvents eventObj)
        {
            if (id != eventObj.eventId)
            {
                return BadRequest("Event ID mismatch.");
            }

            if (ModelState.IsValid)
            {
                eventObj.date = eventObj.date.ToUniversalTime();
                eventObj.time = eventObj.time.ToUniversalTime();

                var docRef = _firestoreDb.Collection("events").Document(id);
                await docRef.SetAsync(eventObj, SetOptions.Overwrite);

                return RedirectToAction(nameof(Index));
            }
            return View(eventObj);
        }

        // GET: Events/Delete/{id}
        public async Task<IActionResult> Delete(string id)
        {
            var docRef = _firestoreDb.Collection("events").Document(id);
            var snapshot = await docRef.GetSnapshotAsync();

            if (snapshot.Exists)
            {
                var eventObj = snapshot.ConvertTo<ManageEvents>();
                return View(eventObj);
            }

            return NotFound();
        }

        // POST: Events/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var docRef = _firestoreDb.Collection("events").Document(id);
            await docRef.DeleteAsync();

            return RedirectToAction(nameof(Index));
        }

        // GET: Events/Rsvps/{eventId}
        public async Task<IActionResult> Rsvps(string eventId)
        {
            // Check if the eventId is null or empty
            if (string.IsNullOrEmpty(eventId))
            {
                return BadRequest("Event ID cannot be null or empty.");
            }

            // Fetch RSVPs for the specified event
            var rsvpsQuery = _firestoreDb.Collection("events").Document(eventId).Collection("rsvps");
            var rsvpsSnapshot = await rsvpsQuery.GetSnapshotAsync();

            var rsvps = new List<Rsvp>();
            foreach (var document in rsvpsSnapshot.Documents)
            {
                var rsvp = document.ConvertTo<Rsvp>();
                rsvps.Add(rsvp);
            }

            return View(rsvps); // Pass the list of RSVPs to the view
        }

        public async Task<IActionResult> Calendar()
        {
            var eventsSnapshot = await _firestoreDb.Collection("events").OrderBy("date").GetSnapshotAsync();
            var events = new List<ManageEvents>();

            foreach (var document in eventsSnapshot.Documents)
            {
                var eventObj = document.ConvertTo<ManageEvents>();
                events.Add(eventObj);
            }

            return View(events); // Return the list of events to the calendar view
        }



    }
}
