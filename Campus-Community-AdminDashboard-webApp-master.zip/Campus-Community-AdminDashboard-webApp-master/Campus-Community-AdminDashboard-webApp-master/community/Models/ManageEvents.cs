﻿using System.ComponentModel.DataAnnotations;
using Google.Cloud.Firestore;

namespace community.Models
{
    [FirestoreData]
    public class ManageEvents
    {
        [FirestoreProperty]
        [Display(Name = "Event UID")]
        public string eventId { get; set; }

        [FirestoreProperty]
        [Display(Name = "Event Title")]
        public string title { get; set; }

        [FirestoreProperty]
        [Display(Name = "Event Description")]
        public string description { get; set; }

        [FirestoreProperty]
        [Display(Name = "Location")]
        public string location { get; set; }

        private DateTime _date;
        [FirestoreProperty]
        public DateTime date
        {
            get => _date;
            set => _date = DateTime.SpecifyKind(value, DateTimeKind.Utc);
        }

        private DateTime _time;
        [FirestoreProperty]
        public DateTime time
        {
            get => _time;
            set => _time = DateTime.SpecifyKind(value, DateTimeKind.Utc);
        }
        public List<string> userEmails { get; set; } = new List<string>();

    }
}
