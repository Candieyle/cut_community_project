﻿using Google.Cloud.Firestore;
using System.ComponentModel.DataAnnotations;

namespace community.Models
{
    [FirestoreData]
    public class Report
    {
        [Key]
        [FirestoreProperty]
        public string reportID { get; set; }

        [FirestoreProperty]
        public string senderName { get; set; }

        [FirestoreProperty]
        public string senderSurname { get; set; }

        [FirestoreProperty]
        public string senderEmail { get; set; }

        [FirestoreProperty]
        public string reportedMessage { get; set; }

        [FirestoreProperty]
        public string groupName { get; set; }

        [FirestoreProperty]
        public string groupID { get; set; }

        // Optionally, you could include a timestamp if you'd like to track when the report was created
        [FirestoreProperty]
        public Timestamp ReportTimestamp { get; set; }
    }
}
