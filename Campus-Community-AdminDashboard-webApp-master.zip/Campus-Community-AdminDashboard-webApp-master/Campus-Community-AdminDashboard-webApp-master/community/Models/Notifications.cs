﻿namespace community.Models
{
    public class Notifications
    {

    }
}
