﻿using Google.Cloud.Firestore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace community.Models
{
    [FirestoreData]
    public class Message
    {
        [FirestoreProperty]
        [Display(Name = "Group UID")]
        public string groupId { get; set; }

        [FirestoreProperty]
        [Display(Name = "Sender E-mail")]
        public string senderEmail { get; set; }

        [FirestoreProperty]
        [Display(Name = "Sender Name")]
        public string senderName { get; set; }

        [FirestoreProperty]
        [Display(Name = "Sender Profile URL")]
        public string senderProfileUrl { get; set; }

        [FirestoreProperty]
        [Display(Name = "Message")]
        public string text { get; set; }

        [FirestoreProperty]
        [Display(Name = "Timestamp")]
        public Timestamp timestamp { get; set; }

        [FirestoreProperty]
        public List<string> attachments { get; set; }
    }
}
