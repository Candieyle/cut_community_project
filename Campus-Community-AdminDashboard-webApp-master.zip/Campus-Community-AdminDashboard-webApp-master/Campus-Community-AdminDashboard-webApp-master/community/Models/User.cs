﻿using Google.Cloud.Firestore;
using System.ComponentModel.DataAnnotations;

namespace community.Models

{
    [FirestoreData]
    public class User
    {
       // Firebase User ID
        [FirestoreProperty]
        [Display(Name = "Name")]
        public string name { get; set; }
        [FirestoreProperty]
        [Display(Name = "Surname")]
        public string surname { get; set; }
        [Required]

        [EmailAddress]
        [FirestoreProperty]
        [Display(Name = "E-mail")]
        public string email { get; set; } // User's email

        [FirestoreProperty]
        [Display(Name = "Phone Number")]
        public string phoneNumber { get; set; }

        [FirestoreProperty]
        [Display(Name = "Student Number")]
        public string studentNumber { get; set; }

        [FirestoreProperty]
        [Display(Name = "Profile Image")]
        public string? profileImageUrl { get; set; }
        [FirestoreProperty]
        [Display(Name = "Password")]
        public string? password { get; set; }
    }
}





