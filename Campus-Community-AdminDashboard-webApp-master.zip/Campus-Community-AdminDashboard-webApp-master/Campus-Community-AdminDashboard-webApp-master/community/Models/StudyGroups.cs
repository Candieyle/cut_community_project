﻿using Google.Cloud.Firestore;
using System.ComponentModel.DataAnnotations;
using System.Drawing;

namespace community.Models
{
    [FirestoreData]
    public class StudyGroups
    {
        [FirestoreProperty]
        [Display(Name = "Creater UID")]
        public string creatorEmail { get; set; }

        [FirestoreProperty]
        [Display(Name = "Group Description")]
        public string description { get; set; }

        [FirestoreProperty]
        [Display(Name = "Group Name")]
        public string groupName { get; set; }

        [FirestoreProperty]
        [Display(Name = "Group UID")]
        public string id { get; set; }

        [FirestoreProperty]
        [Display(Name = "Group Members")]
        public List<string> members { get; set; } 

        [FirestoreProperty]
        [Display(Name = "Group Messages")]
        public List<string> messages { get; set; }

        

        //public Image GroupProfile { get; set; }

    }
}
