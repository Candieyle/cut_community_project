﻿using Google.Cloud.Firestore;

namespace community.Models
{
    [FirestoreData]
    public class Rsvp
    {
        [FirestoreProperty]
        public string eventId { get; set; }

        [FirestoreProperty]
        public string eventTitle { get; set; }

        [FirestoreProperty]
        public string studentId { get; set; }

        [FirestoreProperty]
        public string userId { get; set; }  // This should be the email

        [FirestoreProperty]
        public string userName { get; set; }
    }
}
